# Full Notes Changelog

## v1.0.2

- Cleaned native/gizmo tooltip behavior for drag/reorder/UI action areas.
- Added dedicated Mirror Objects icons.
- Added expandable footer shortcut assignment controls.
- Added settings cog and restored footer hotkey icon behavior.
- Enlarged More Tools section reorder grip.

## Dev_v1.2.3

- Enlarged the closed launcher emblem and darkened the launcher background.

## Dev_v1.2.2

- Removed the 3D View N-panel/sidebar tab.

## Dev_v1.2.0

- Added the first window-state layer for Witch Quickbar.
- Added Full, Minimized, and Closed Launcher states.
- Added header controls for minimize, maximize, and close.
- Added a small draggable launcher button for the closed state.
- Added Open/Close and Maximize Open/Close hotkey targets.
- Added shortcut assignment behavior so Maximize can default to Ctrl + the assigned Open/Close shortcut.

## Dev_v1.1.2

- Fixed cycle traversal through disabled modes.

## Dev_v1.1.1

- Fixed mode tooltip behavior.

## Dev_v1.1.0

- Rebuilt overlay input using View3D gizmo hit targets and dedicated undoable operators for scene-changing tools.
