# Notes Changelog — v1.0.2

- Cleaned tooltip behavior for dock drag/reorder/UI action areas.
- Added Mirror Objects icons for pivot and mirror selected controls.
- Added expandable footer hotkey assignment controls.
- Restored footer icon separation: hotkey icon for hotkeys, cog for settings, emblem only for closed launcher.
- Enlarged section reorder grip indicator.
